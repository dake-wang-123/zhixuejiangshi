module.exports = [
  {
    "category": "0-3岁（6课）",
    "category_sort": 1,
    "lesson_code": "A01",
    "seq": 1,
    "title": "听懂\"婴语\"：读懂宝宝的哭声与信号"
  },
  {
    "category": "0-3岁（6课）",
    "category_sort": 1,
    "lesson_code": "A02",
    "seq": 2,
    "title": "陌生人焦虑与分离抗议：帮宝宝建立安全基地"
  },
  {
    "category": "0-3岁（6课）",
    "category_sort": 1,
    "lesson_code": "A03",
    "seq": 3,
    "title": "什么都想抓，什么都往嘴里放：保护学步儿的探索天性"
  },
  {
    "category": "0-3岁（6课）",
    "category_sort": 1,
    "lesson_code": "A04",
    "seq": 4,
    "title": "\"我的！我的\"：物权意识敏感期——当孩子想把所有东西都带回家"
  },
  {
    "category": "0-3岁（6课）",
    "category_sort": 1,
    "lesson_code": "A05",
    "seq": 5,
    "title": "\"不！就不\"：秩序敏感期的执拗与应对智慧"
  },
  {
    "category": "0-3岁（6课）",
    "category_sort": 1,
    "lesson_code": "A06",
    "seq": 6,
    "title": "\"为什么\"大爆发：语言敏感期与认知飞跃的黄金引导"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B01",
    "seq": 1,
    "title": "破解分离焦虑：和孩子一起笑着入园"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B02",
    "seq": 2,
    "title": "\"我自己来\"：呵护主动性萌芽，激发成长内驱力"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B03",
    "seq": 3,
    "title": "认识\"情绪小怪兽\"：做孩子的情感翻译官"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B04",
    "seq": 4,
    "title": "立规矩≠伤感情：温柔而坚定的早期规则建立"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B05",
    "seq": 5,
    "title": "\"我不跟你玩了\"：升级社交技能，化解同伴冲突"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B06",
    "seq": 6,
    "title": "\"我就要赢\"：在游戏与竞争中培养抗挫力"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B07",
    "seq": 7,
    "title": "从\"坐不住\"到\"能专注\"：在游戏中培育注意力"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B08",
    "seq": 8,
    "title": "\"我不敢……\"：支持孩子面对挑战，勇敢而非冒进"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B09",
    "seq": 9,
    "title": "\"等等，我还没玩够\"：时间管理与任务意识的启蒙"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B10",
    "seq": 10,
    "title": "\"学习小达人\"：大班孩子的学习能力准备"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B11",
    "seq": 11,
    "title": "幼小衔接，到底衔接什么"
  },
  {
    "category": "3-6岁（12课）",
    "category_sort": 2,
    "lesson_code": "B12",
    "seq": 12,
    "title": "\"我永远学不会\"：应对挫折，塑造成长型思维"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C01",
    "seq": 1,
    "title": "帮助孩子华丽转身：幼小衔接适应性指南"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C02",
    "seq": 2,
    "title": "坐得住的秘密：专注力培养从保护开始"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C03",
    "seq": 3,
    "title": "\"他为什么不跟我玩\"：一年级社交起步指南"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C04",
    "seq": 4,
    "title": "\"我不想上学\"：破解厌学情绪的早期信号"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C05",
    "seq": 5,
    "title": "生活里的\"刻意练习\"：从拍黄瓜到洗碗，培养孩子的学习基本功"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C06",
    "seq": 6,
    "title": "催不动，喊不应：看见冲突背后的孩子，重建亲子联结"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C07",
    "seq": 7,
    "title": "别让外在成绩成为衡量孩子的唯一标准"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C08",
    "seq": 8,
    "title": "\"妈妈，我害怕……\"：识别与应对儿童焦虑"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C09",
    "seq": 9,
    "title": "\"三年级现象\"解密：成绩滑坡背后的真相"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C10",
    "seq": 10,
    "title": "\"作业拉锯战\"终结：培养自主学习能力"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C11",
    "seq": 11,
    "title": "\"他们不跟我玩\"：校园小团体的应对之道"
  },
  {
    "category": "6-9岁（12课）",
    "category_sort": 3,
    "lesson_code": "C12",
    "seq": 12,
    "title": "\"我就是粗心\"：警惕\"粗心\"背后的真问题"
  },
  {
    "category": "9-12岁（6课）",
    "category_sort": 4,
    "lesson_code": "D01",
    "seq": 1,
    "title": "辅导不了，怎么办：当孩子的学业难度超过你的能力"
  },
  {
    "category": "9-12岁（6课）",
    "category_sort": 4,
    "lesson_code": "D02",
    "seq": 2,
    "title": "\"说好看半小时手机，一小时了还抱着\"：手机管理的\"战斗\"与\"合作\""
  },
  {
    "category": "9-12岁（6课）",
    "category_sort": 4,
    "lesson_code": "D03",
    "seq": 3,
    "title": "从\"要我学\"到\"我能自己学\"：高年级自主学习能力培养"
  },
  {
    "category": "9-12岁（6课）",
    "category_sort": 4,
    "lesson_code": "D04",
    "seq": 4,
    "title": "沉默的背后：如何让孩子愿意跟你说话"
  },
  {
    "category": "9-12岁（6课）",
    "category_sort": 4,
    "lesson_code": "D05",
    "seq": 5,
    "title": "小升初：先稳住自己，再支持孩子"
  },
  {
    "category": "9-12岁（6课）",
    "category_sort": 4,
    "lesson_code": "D06",
    "seq": 6,
    "title": "准备告别童年：毕业季的心理过渡与成长赋能"
  },
  {
    "category": "12-15岁（6课）",
    "category_sort": 5,
    "lesson_code": "E01",
    "seq": 1,
    "title": "初中新生适应：帮助孩子平稳度过新环境带来的\"心理地震期\""
  },
  {
    "category": "12-15岁（6课）",
    "category_sort": 5,
    "lesson_code": "E02",
    "seq": 2,
    "title": "\"凭什么管我\"：青春期叛逆的正面解读与应对"
  },
  {
    "category": "12-15岁（6课）",
    "category_sort": 5,
    "lesson_code": "E03",
    "seq": 3,
    "title": "当孩子说\"不想活了\"：识别与应对青少年抑郁"
  },
  {
    "category": "12-15岁（6课）",
    "category_sort": 5,
    "lesson_code": "E04",
    "seq": 4,
    "title": "当孩子不去学校：厌学的理解与家庭应对"
  },
  {
    "category": "12-15岁（6课）",
    "category_sort": 5,
    "lesson_code": "E05",
    "seq": 5,
    "title": "不只是分数：在升学压力下坚守孩子的自我价值感"
  },
  {
    "category": "12-15岁（6课）",
    "category_sort": 5,
    "lesson_code": "E06",
    "seq": 6,
    "title": "帮助孩子减压：初三学生家长能做的支持"
  },
  {
    "category": "15-18岁（6课）",
    "category_sort": 6,
    "lesson_code": "F01",
    "seq": 1,
    "title": "高一适应：从\"佼佼者\"到\"普通一员\"的心理重建"
  },
  {
    "category": "15-18岁（6课）",
    "category_sort": 6,
    "lesson_code": "F02",
    "seq": 2,
    "title": "选科迷思：如何借助AI帮助孩子做出适合自己的选择"
  },
  {
    "category": "15-18岁（6课）",
    "category_sort": 6,
    "lesson_code": "F03",
    "seq": 3,
    "title": "AI时代的学习升级：高二学生家长如何引导孩子用AI高效学习"
  },
  {
    "category": "15-18岁（6课）",
    "category_sort": 6,
    "lesson_code": "F04",
    "seq": 4,
    "title": "青春期的爱情：如何跟高中生探讨恋爱话题"
  },
  {
    "category": "15-18岁（6课）",
    "category_sort": 6,
    "lesson_code": "F05",
    "seq": 5,
    "title": "高三陪跑：做孩子的\"情绪稳定器\"而非\"增压器\""
  },
  {
    "category": "15-18岁（6课）",
    "category_sort": 6,
    "lesson_code": "F06",
    "seq": 6,
    "title": "AI辅助志愿填报：高三学生家长的信息参谋之道"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G01",
    "seq": 1,
    "title": "闭嘴的功夫：在家庭琐事中停止语言冲突"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G02",
    "seq": 2,
    "title": "劳谦的力量：如何不带着怨气承担责任"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G03",
    "seq": 3,
    "title": "格物致良知：跨越\"知道\"与\"做到\"的鸿沟"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G04",
    "seq": 4,
    "title": "慎独自省：家长如何通过自我觉察影响孩子"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G05",
    "seq": 5,
    "title": "\"柔顺中正敬\"：用五个字重塑复杂的家庭关系"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G06",
    "seq": 6,
    "title": "王者父母：做孩子生命中的背景而非主宰"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G07",
    "seq": 7,
    "title": "青春蒙卦：帮助孩子度过混乱的青春期"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G08",
    "seq": 8,
    "title": "\"叩其两端\"：用提问激发孩子的良知和思考"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G09",
    "seq": 9,
    "title": "从\"小我\"到\"大我\"：培养孩子一生的内驱力"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G10",
    "seq": 10,
    "title": "家庭的\"中孚\"之信：守护与重建亲子间的信任关系"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G11",
    "seq": 11,
    "title": "\"必有事业\"：让生活琐碎成为你的修行道场"
  },
  {
    "category": "国学父母修养课（12课）",
    "category_sort": 7,
    "lesson_code": "G12",
    "seq": 12,
    "title": "中国式共情：推己及人，如何真正做到将心比心"
  }
]
