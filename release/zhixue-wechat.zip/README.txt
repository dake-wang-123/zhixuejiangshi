Family education lecturer miniprogram

Import the extracted folder family-edu-miniprogram.
That folder must contain app.json and pages/.

Windows:
1. Download the zip. Do not open the zip as a WeChat project.
2. Right-click -> Extract All.
3. Open the extracted folder, then enter family-edu-miniprogram.
4. Confirm you can see app.json, then import that folder in WeChat DevTools.
5. AppID: wx0277d4abe92dd8a3
6. This package does not declare third-party plugins.
